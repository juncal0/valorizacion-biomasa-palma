# Notas metodológicas para el artículo — Aspectos a incluir en Métodos

*Documento de trabajo — recopila las decisiones metodológicas tomadas durante la limpieza y preparación de datos. Organizar y redactar en prosa cuando se escriba la sección de Métodos del artículo.*

---

## 1. Fuente de datos y alcance

- Datos primarios de campo de **6 plantas extractoras de aceite de palma en el departamento del Magdalena, Colombia** (Planta A-F), recolectados como parte del proyecto doctoral.
- Alcance: Línea base (desempeño actual) vs. **Escenario 1** (cogeneración térmica: turbinas de extracción-condensación) vs. **Escenario 2** (digestión anaeróbica de POME + cogeneración).
- Los datos crudos provienen de un archivo de trabajo (`Escenarios.xlsx`) con más de 15 hojas de cálculo, construido durante el desarrollo de la tesis doctoral.

## 2. Estructuración de datos (data wrangling)

- Los datos originales estaban en formato "ancho" (una columna por planta) orientado a lectura humana, no a análisis. Se transformaron a formato "tidy" (`Parámetro`, `Unidad`, `Etapa`, `Planta`, `Valor`) usando Python (pandas) para permitir el modelado posterior en Pyomo.
- Se identificaron y organizaron **11 etapas del proceso productivo**: Recepción/General, Esterilización, Desfrutado, Digestión y prensado, Clarificación, Recuperación de aceite, Almacenamiento, Secado de nueces, Rotura de nuez, Calentamiento de agua de proceso, y Caldera.
- **Nota metodológica:** el código de limpieza y todas las transformaciones quedan documentadas en notebooks de Python (Jupyter) — se recomienda mencionar esto en el artículo como buena práctica de reproducibilidad científica, y considerar publicar el repositorio (GitHub) como material suplementario.

## 3. Tratamiento de valores derivados y datos faltantes

- Se identificaron valores "específicos por tonelada de fruto procesado" (ej. vapor de esterilización, condensados) que estaban en filas sin etiqueta en el archivo original — se confirmó matemáticamente (relación exacta con la capacidad de planta) y se etiquetaron explícitamente como `(específico por tRFF)`.
- Se corrigió un error de unidad en el dato original de "Humedad de secado" (aparecía como °C, debía ser %).
- El parámetro "Flujo de aire de secado" no cuenta con dato medido en campo — se documenta como **dato pendiente de estimación** (a resolver mediante balance psicrométrico en la etapa de modelado, no mediante sustitución arbitraria).
- Las eficiencias reportadas originalmente en la hoja de datos base **no se usan como dato de entrada** — se identificó que dependían de una fórmula de Excel con referencia rota. Se recalculan desde cero a partir del balance de masa y energía en el modelo Pyomo, lo cual permite usarlas como variables de salida auditable y como benchmark de validación.

## 4. Propiedades de la biomasa

- Caracterización fisicoquímica (humedad, C, H, O, N, S, HHV, LHV) para 5 tipos de biomasa residual: EFB, Fibra, PKS, Pressed EFB, Dry EFB — reportada como promedio ± desviación estándar.
- **Correlación para poder calorífico superior (HHV):** ecuación propia ("Present study") sin término de ceniza (Ash), por no contar con datos de ceniza para la biomasa de palma:
  
  `HHV = 0.3443·C + 1.192·H − 0.113·O − 0.024·N + 0.093·S`
  
  (C, H, O, N, S en % base seca). Se validó por consistencia interna contra los valores de HHV reportados (coincidencia exacta) — **aclarar en el artículo que esto confirma consistencia de la tabla de datos, no una validación independiente contra literatura externa**, ya que el HHV reportado probablemente se calculó con la misma correlación.
- Capacidad calorífica (Cp) por componente de biomasa (agua, cuesco, almendra, aceite de palma, fibra, EFB, lodos) tomada de tabla de referencia (transcrita de imagen incrustada en el Excel original — pendiente confirmar cita bibliográfica de la fuente original de esta tabla).

## 5. Costos de inversión (CAPEX)

- **Fuente:** cotizaciones reales obtenidas durante el estudio (proveedores: AIC, MFMI, AVM, Tecnintegral), promediadas por área de proceso para construir la tabla resumen (USD, referenciadas a una capacidad de 15 tRFF·h⁻¹).
- **Curva de costo de cogeneración** (economías de escala vs. capacidad instalada), usada para dar robustez al análisis en vez de un precio unitario fijo:
  
  `CAPEX (USD/kW) = -900.6·ln(P) + 10,841`
  
  Fuente: Malico et al. (2019) — **citar explícitamente en el artículo**; señalar como limitación la transferibilidad geográfica del dato (contexto europeo/Portugal aplicado a Colombia).
- **Ajuste temporal de costos:** todos los valores llevados a USD 2026 mediante el índice CEPCI (Chemical Engineering Plant Cost Index):
  - CEPCI 2019 = 607.5; CEPCI 2021 = 708.8; CEPCI 2026 ≈ 873.8 (estimado)
  - **Nota de limitación a incluir en el artículo:** el valor de CEPCI 2026 es una extrapolación (el año está en curso y el índice es ahora un servicio de suscripción paga desde agosto de 2024) — se calculó a partir de la variación interanual más reciente reportada (+7.5% a febrero 2026 vs. febrero 2025). Documentar fecha de consulta y fuente.
- **Estimación de Pretratamiento térmico** (sin cotización disponible): extrapolado por regla de escalamiento de capacidad (regla de los "seis décimos", exponente n=0.6) a partir de un costo de referencia de 1.4M USD para una planta de 150,000 t/año (dato de 2021, ajustado a 2026 con CEPCI). **Señalar como limitación:** el exponente 0.6 es un valor estándar genérico de ingeniería de costos, no específico para pretratamiento de biomasa — sugerir revisión de literatura especializada si se dispone de tiempo antes del envío.

## 6. Factores de emisión y balance de GEI

- **Factores de emisión de CH4 y N2O** para combustión de biomasa sólida y biogás: valores por defecto IPCC, tomados de Gómez et al. (2017) — Tabla 5 (CH4: 30 kg/TJ biomasa sólida, 1 kg/TJ biogás; N2O: 4 kg/TJ biomasa sólida, 0.1 kg/TJ biogás; GWP100: CH4=21, N2O=310).
- **Convención metodológica:** el CO2 de la combustión de biomasa/biogás se considera **biogénico (neutro)** y no se contabiliza en el inventario de GEI, siguiendo la convención estándar IPCC — solo se contabilizan CH4 y N2O (como CO2-eq) de estas fuentes.
- **Factor de emisión de diésel:** 74,100 kg CO2/TJ (IPCC 2006 Guidelines, Vol. 2) — validado exitosamente contra los valores de la hoja original de la tesis (línea base).
- **Factor de emisión de la red eléctrica nacional (Colombia):** 163.4 g CO2/kWh — mismo valor usado en la publicación previa (JCLP 2024) del autor, por consistencia metodológica. **Nota de limitación a incluir en el artículo:** no se identificó un estudio más reciente/actualizado que reemplace este factor; se mantiene por trazabilidad con el trabajo previo publicado.
- **Crédito de absorción de carbono del cultivo de palma:** -135.04 kg CO2/tRFF procesado, aplicado como descuento fijo al balance neto de GEI en los 3 casos (Línea base, Esc. 1, Esc. 2) — dato consolidado de estudio previo ya usado en la publicación anterior del autor (mantiene consistencia entre ambos artículos).
- **Hallazgo relevante para Métodos:** se identificó que la hoja original de resultados de emisiones (`EmisionesCO2`) contenía un error de cálculo en el factor de CH4 aplicado a los escenarios de valorización (aprox. 250× el valor correcto, probablemente por referencia de celda rota) — **se optó por reconstruir el cálculo desde cero** en vez de reutilizar esos resultados, aplicando los factores IPCC directamente sobre la energía (TJ) que calculará el modelo Pyomo. Esto es coherente con la misma decisión tomada para las eficiencias energéticas (Sección 3).
- **Lógica de flujo energético confirmada (clave para las restricciones del modelo Pyomo):**
  - *Escenario 1 (térmico):* biomasa sólida → combustión → vapor total → una fracción va al proceso industrial (esterilización, digestión, etc.), el resto acciona la turbina → genera electricidad → excedente = generación − consumo propio.
  - *Escenario 2 (biogás):* POME → digestión anaeróbica → biogás → combustión total del biogás → toda la energía va a generación eléctrica (no hay división térmica/eléctrica) → excedente = generación − consumo propio.

## 7. Módulo social — impacto poblacional del excedente eléctrico

- **Nomenclatura de escenarios estandarizada:** se reemplazó la nomenclatura interna original ("ERI-1"/"ERI-2", Escenario de Revalorización Integral) por `Escenario_1_Termico` y `Escenario_2_Biogas`, consistente con el resto del proyecto.
- **Indicador principal de impacto social propuesto:** *viviendas rurales equivalentes abastecidas* = excedente eléctrico (kWh-año) ÷ consumo promedio por vivienda rural departamental (kWh-año). Se prefirió sobre un indicador de "% de cobertura departamental" porque es más tangible/interpretable para el lector y evita la confusión de valores >100% (una sola planta comparada contra la demanda rural de todo el departamento).
- **Indicador complementario:** conversión a *personas equivalentes beneficiadas*, usando el promedio de **3.7 personas por hogar** (DANE, Censo Nacional de Población y Vivienda — CNPV 2018, dato departamental para Magdalena). Se validó cruzado: el total de hogares particulares del DANE para Magdalena (319,306) coincide exactamente con el dato ya usado en la hoja de cálculo original de la tesis.
- **Datos base de demanda residencial departamental (Magdalena, 2025):** rural = 30.3 GWh-año, urbana = 1,209 GWh-año, industrial y comercio = 1,190.7 GWh-año (suma total = 2,430 GWh-año, validada).
- **Limitación a incluir explícitamente en el artículo:**
  1. El DANE no reporta el promedio de personas por hogar desagregado por zona rural/urbana a nivel departamental en la fuente consultada — se usa el promedio departamental general (3.7) para ambas zonas. (Referencia nacional para contexto: la Encuesta de Calidad de Vida más reciente reporta 2.99 personas/hogar rural vs. 2.82 urbano a nivel *nacional*, sugiriendo que el valor rural real podría ser marginalmente distinto al promedio usado).
  2. No se dispone de información geo-referenciada a nivel de municipio/zona de influencia directa de cada planta extractora — el indicador de "población beneficiada" se calcula contra la demanda rural **agregada del departamento**, no contra la población específica del área de influencia de cada planta. Esto sobreestima el impacto local real y debe interpretarse como un indicador de **potencial teórico departamental**, no de alcance geográfico verificado.
- **Igual que en Emisiones y CAPEX:** los bloques de resultados de la hoja original (excedente eléctrico y % de cobertura por planta) se reconstruyen desde cero a partir de los resultados del modelo Pyomo, en vez de reutilizar los valores de la hoja de cálculo, por trazabilidad.

## 8. Hoja `Eficiencia` — consolidación de balances de masa y energía (línea base)

- Esta hoja consolida el balance de masa y energía completo de la línea base (columnas A-H, por planta), en el mismo formato tidy ya usado en `Datos_Base`.
- **Columna I:** corresponde a un caso de estudio específico (planta de referencia) usado para modelar el proceso de **esterilización continua** — tecnología que reemplaza la esterilización convencional en los Escenarios 1 y 2 (ver Sección 9 para la justificación).
- **Cálculo de calor específico (Cp) ponderado del fruto esterilizado:** se identificó un sub-cálculo (columnas J-M) que determina el Cp de la mezcla de fruto a partir de su composición (fibra, nueces, agua, aceite, etc.), ponderando el Cp de cada componente por su fracción en peso. Resultado: **Cp ponderado ≈ 2.2027 kJ/kg·K**. Este valor se formaliza como función de Python (no como constante fija) para que se recalcule automáticamente si cambia la composición del fruto.

### 8.1 Cogeneración existente en línea base (filas 217-244)

- Se identificó un desglose de la **fuente del consumo eléctrico por planta** (filas 220-223: fracciones de Biomasa/Biogás/Red nacional/Diésel) — dato reportado directamente, sin fórmula intermedia, por lo tanto trazable.
- **Hallazgo clave:** en línea base, **solo Planta A tiene cogeneración con biomasa** (79.13% de su consumo eléctrico autogenerado), consistente con lo indicado por el autor. **Adicionalmente se detectó que Planta D ya cuenta con un sistema de biogás** cubriendo el 70% de su consumo eléctrico — hallazgo no documentado previamente en estas notas; **queda pendiente decidir si se incorpora al alcance del modelo de línea base o se documenta como nota aparte** (no confundir con el Escenario 2, que es un sistema de biogás *nuevo/mejorado* a evaluar para las 6 plantas).
- **Discrepancia resuelta:** la misma hoja reporta un parámetro separado "Eficiencia cogeneración" = 12.8% (fila 234, columna C, Planta A — valor fijo, no fórmula). Al intentar usar este valor para derivar la electricidad autogenerada a partir de la energía térmica total de la caldera (fila 237), el resultado (~8.29 millones kWh/año) no reconcilia con el consumo eléctrico total de la planta (3,083,731 kWh/año) — es más del triple. **Se determinó que el 12.8% es un dato de referencia/contexto (eficiencia típica reportada de la turbina de contrapresión existente) y no debe usarse como insumo de cálculo directo**, ya que aplicarlo sobre el total de energía térmica de caldera sobreestima la generación. **Se adopta como fuente de entrada del modelo el desglose de fuente del consumo eléctrico** (fracción Biomasa × consumo eléctrico total), por ser un dato medido y trazable sin ambigüedad de fórmula. El 12.8% se mantiene documentado como referencia de validación cualitativa (orden de magnitud típico de una turbina de contrapresión antigua de baja eficiencia).
- **Electricidad autogenerada por cogeneración, Planta A (línea base):** 3,083,731 kWh/año × 79.13% ≈ **2,439,943 kWh/año**.

## 9. Enfoque de modelado para la etapa de esterilización (decisión de alcance)

- **Decisión metodológica clave:** dado que el objetivo central del artículo es la comparativa entre configuraciones (no un análisis termodinámico detallado de la esterilización), se adopta un enfoque práctico:
  1. **Línea base:** se usa el consumo de vapor de esterilización **reportado/medido en campo** (dato real de `Datos_Base`), sin derivarlo de un balance teórico.
  2. **Escenarios 1 y 2:** la esterilización convencional de la línea base se **reemplaza por esterilización continua**, usando como referencia el caso de estudio de la columna I de `Eficiencia`, escalado a la capacidad de cada una de las 6 plantas.
  3. El balance teórico detallado (calor sensible del fruto + calor latente de condensación del vapor, usando el Cp ponderado calculado arriba) se documenta como **método de validación/respaldo**, disponible como función de Python, pero no como el mecanismo principal de cálculo — para no comprometer alcance y tiempo del proyecto en afinar un balance térmico que no es el foco central del estudio.
- **Justificación técnica del cambio a esterilización continua en los escenarios:** la esterilización continua requiere un **flujo de vapor constante, sin variaciones de presión** — característica ideal para integrarse con una **turbina de extracción-condensación** (Escenario 1), ya que permite extraer exactamente el vapor que demanda el proceso a presión constante, mientras el vapor restante se destina completamente a condensación para generación eléctrica adicional. Esta es una restricción de balance central en la formulación del modelo Pyomo para el Escenario 1.
- **Trazabilidad de fórmulas:** se confirmó que las fórmulas originales de Excel (no solo los valores calculados) son extraíbles con Python (`openpyxl`, modo fórmula). Por ejemplo, la fórmula de "Vapor teórico" se leyó explícitamente y coincide con el balance de calor sensible + latente descrito por el autor, incluyendo referencias cruzadas a la hoja `Biomass` (calores específicos) y constantes de entalpía de vapor (K3=2703, K4=2626 kJ/kg). Esto permite traducir el modelo de Excel a Python con fidelidad exacta cuando se requiera, en vez de reconstruir la lógica de memoria.
- **Escalamiento confirmado (esterilización continua):** consumo específico = **315 kg vapor/tRFF procesado** (derivado del caso de estudio, capacidad 40,000 kg RFF/h → 12,600 kg vapor/h), escalado linealmente a la capacidad de cada una de las 6 plantas — mismo criterio de aproximación usado para los costos de inversión "por capacidad de RFF" en la hoja CAPEX.
- **Tabla de demanda energética por etapa de proceso (columnas M-Y):** desglose de demanda eléctrica (kWe) y térmica (kWth) por cada etapa (Recepción, Esterilización, Desfrutado, Prensado de raquis, Digestión y prensado, Clarificación, Palmistería, Almacenamiento, Extracción de palmiste, Calentamiento de agua, Caldera, Planta de tratamiento de agua). Se organizó en formato tidy (`Etapa`, `Planta`, `Tipo_energia`, `Valor_kW`) para permitir cruce directo con la clasificación de `Etapa` ya usada en `Datos_Base`. Validado: la fila "Total" coincide exactamente con "Demanda térmica proceso LB" de `Scenarios1` (11,627.41 kWth, Planta A).

## 12. Análisis de estacionalidad y almacenamiento de biomasa (material para Discusión)

- **Decisión de alcance:** en vez de correr el modelo Pyomo con progresión temporal mensual completa (que multiplicaría el esfuerzo de modelado sin cambiar necesariamente la conclusión comparativa entre escenarios), se optó por un análisis ligero y complementario usando los datos mensuales reales de `RFF evolution` (2022) como corrección/sensibilidad — dejando el modelo mensual completo como trabajo futuro si el cronograma lo permite.
- **Hallazgo de estacionalidad:** patrón semestral claro en las 6 plantas — procesamiento por encima del promedio de enero a mayo (factor de estacionalidad 1.03-1.28, pico en abril), y por debajo de junio a diciembre (factor 0.87-0.97).
- **Indicador propuesto — buffer de almacenamiento requerido:** máximo déficit acumulado de biomasa a lo largo del año (respecto al promedio mensual), como aproximación al tamaño de almacenamiento necesario para sostener una generación energética constante todo el año. Resultados por planta:

| Planta | Buffer requerido (t) | % del procesamiento anual |
|---|---|---|
| A | 14,461 | 8.3% |
| B | 23,777 | 11.5% (mayor exigencia) |
| C | 5,389 | 3.0% (menor exigencia) |
| D | 5,772 | 4.4% |
| E | 5,295 | 7.2% |
| F | 3,042 | 7.9% |

- **Ángulo de discusión propuesto:** la necesidad de almacenamiento varía sustancialmente entre plantas (3.0%-11.5% del procesamiento anual), sugiriendo que la viabilidad de una estrategia de almacenamiento de biomasa para sostener generación constante depende del perfil de estacionalidad específico de cada planta, no de una política uniforme departamental. Valores en el rango de ~10% del procesamiento anual son logísticamente manejables, lo que respalda la viabilidad técnica del almacenamiento como estrategia complementaria a los escenarios de valorización evaluados.
- **Limitación:** los datos de estacionalidad corresponden a 2022 (un solo año) — se documenta como supuesto que el patrón se mantiene representativo; datos más recientes (disponibles hasta el año actual) podrían incorporarse como análisis de sensibilidad adicional si el tiempo lo permite.
- **Nota de calidad de datos:** se detectó una discrepancia menor entre el acumulado de `RFF evolution` para Planta E (73,534.36 t) y el valor correspondiente en `Datos_Base` (75,534 t) — diferencia de ~2,000 t (~2.6%), no crítica para el análisis pero documentada por transparencia.

## 13. Pendientes de documentar (a resolver en las siguientes hojas del Excel)

- `Scenarios1` / `Scenarios2` (hojas visibles y consolidadas — no confundir con `Scenario 1`/`Scenario 2`, diagramas de flujo ocultos) — balance de masa y energía completo por escenario, base principal del modelo Pyomo.

## 15. Parámetros de sustitución tecnológica de proceso (Tabla 10, tesis)

- **Esterilización continua** (reemplaza esterilización convencional en Escenarios 1 y 2, por su compatibilidad operativa con el sistema de turbina — flujo de vapor constante sin variaciones de presión):
  - Consumo de vapor: **315 kg·tRFF⁻¹** (fuente: caso de estudio, hoja `Eficiencia` de la tesis — confirmado como el valor correcto).
  - Consumo de electricidad: 1.95 kWh·tRFF⁻¹ (fuente: Tabla 10 tesis, datos suministrados por POM).
  - Condiciones de operación: 1 bar, 120°C (fuente: Tabla 10 tesis).
  - **Discrepancia resuelta:** la Tabla 10 de la tesis reporta inicialmente 542 kg·tRFF⁻¹ para "Consumo de vapor" de esterilización continua — se identificó como un probable error de redacción/etiquetado en la tesis (ese valor es más cercano al consumo total de planta con esterilización *convencional*, no al específico del sistema continuo). Se confirmó con el autor que 315 kg·tRFF⁻¹ es el valor correcto, consistente con que la esterilización continua (sistema atmosférico) consume más vapor que la convencional (~180-220 kg·tRFF⁻¹ típico), pero se adopta por su compatibilidad operativa con la turbina, no por eficiencia de vapor.
- **Clarificación dinámica** (reemplaza clarificación convencional — reduce consumo de vapor):
  - Consumo de vapor: 0.6 kg·tRFF⁻¹, electricidad: 15 kWh·tRFF⁻¹, agua: 90 L·tRFF⁻¹.
  - Fuente: Fernández et al. (2016).
- **Sistema de cogeneración con turbina de extracción-condensación (Escenario 1) — Tabla 6 de la tesis:**
  - Caldera: 48 bar, 470°C, eficiencia térmica 85% (Yusniati et al., 2018), agua de alimentación a 129°C.
  - Turbina — extracción de proceso: 5 bar, 159°C (vapor ligeramente sobrecalentado; se reduce de presión aguas abajo hasta 1 bar/120°C para alimentar la esterilización continua de la Tabla 10 y el resto del proceso).
  - Turbina — condensación: 0.22 bar, 62°C (validado: coincide con la temperatura de saturación del agua a esa presión, confirmando consistencia termodinámica del dato). Fuente: Montoya et al. (2020).
  - Eficiencia isentrópica turbina: 77% (modo extracción-condensación) / 75% (modo contrapresión, aplica a Escenario 2). Eficiencia mecánica 98%, eficiencia eléctrica del generador 95%. Autoconsumo de equipos auxiliares: 14.2% (se resta de la generación bruta antes de calcular el excedente exportable). Fuente: Booneimsri et al. (2018).
  - **Discrepancia resuelta:** la tesis presenta dos tablas con parámetros parcialmente distintos para este mismo sistema — Tabla 12 ("Sistema de extracción-condensación": 400°C sin presión de caldera reportada, presión de extracción de proceso 0.3 bar, eficiencia isentrópica 85%) y Tabla 6 ("Parámetros asumidos...": 48 bar/470°C, presión de proceso 5 bar, eficiencia isentrópica 77%). Se intentó inicialmente inferir la presión de caldera de la Tabla 12 a partir de una entalpía de cálculo reportada (3,366.7 kJ/kg a 400°C), pero se determinó mediante verificación con IAPWS-IF97 que esa combinación T-h es termodinámicamente inconsistente (esa entalpía no es alcanzable a 400°C en ningún rango de presión de caldera). Se optó por adoptar la **Tabla 6 como fuente única y definitiva**, al ser explícitamente la tabla de "parámetros asumidos" para la simulación, con mejor trazabilidad de referencias y consistencia termodinámica verificada (validación cruzada exitosa del punto de condensación 0.22 bar/62°C contra IAPWS-IF97).
- **Sistema de digestión anaeróbica (Tabla 13):** consumo de electricidad 0.227 kWh·Nm⁻³CH4, disponibilidad de biogás en POME 0.35 Nm³·kgDQO⁻¹ (Rahayu et al., 2015), disponibilidad de lodos 0.03 t·tEfluente⁻¹ (Ocampo Batlle et al., 2020). DQO de entrada por planta obtenido de `Scenarios1` (fila 40): 74,496-122,973 mg/L según planta.
  - **Nota metodológica sobre la eficiencia de conversión DQO→biogás (DQO_eff, Ecuación 6):** se mantiene como parámetro fijo por ahora; se documenta como candidato para análisis de sensibilidad en una fase posterior del modelo, no se explora en la Fase 1 (validación).
- **Potencial bioquímico de metano (BMP) de EFB pretratado (Ecuaciones 7-8, Tabla 7):** modelo de predicción estadística de Thomsen, Spliid & Østergård (2014, *Bioresource Technology* 154:80-86). Se identificó que la cita de esta ecuación en la tesis original estaba incompleta/mal referenciada; se confirmó la fuente correcta mediante búsqueda bibliográfica, localizando además la misma ecuación (Eq. 4) reproducida y correctamente citada en Gutiérrez, Cabello Eras, Hens & Vandecasteele (2020, *Journal of Cleaner Production* 262:121317) — lo que valida los 4 coeficientes de regresión (378, 354, −194, 313).
  - **Validación exitosa (100% exacta):** el primer intento de reproducir el valor reportado (273.51 L CH4/kg SV) dio 225.6 L CH4/kg SV — una diferencia de ~17% causada por una **mala interpretación de la variable x_R** (residual). Se confirmó, con la fuente completa, que x_R **no es el contenido de ceniza** de la Tabla 7 (5.7%), sino el **complemento matemático** de las otras tres fracciones: x_R = 1 − (x_C + x_H + x_L) = 1 − (0.43+0.21+0.15) = 0.21 (representa lípidos, proteínas, pectina, taninos, etc., no solo ceniza). Al recalcular con x_R = 0.21 en vez de 0.057, el resultado coincide **exacto**: 273.51 = 273.51 L CH4/kg SV.
  - **Decisión metodológica:** el BMP del EFB pretratado se calcula mediante la función completa (no como valor fijo), permitiendo que se recalcule automáticamente si cambia la composición de entrada — mayor trazabilidad y consistencia con el resto del modelo.
  - **Pendiente:** determinar el flujo de material inerte/digestato que sale del reactor de biogás — relevante para ambos escenarios (valorización adicional, artículo de referencia pendiente de revisar con el autor).
- **Reactor de pretratamiento térmico de EFB (steam explosion, Tabla 14) — Escenario 2:** 
  vapor a 200°C / 16 bar, relación de flujo 0.3 t vapor·t biomasa⁻¹, recuperación de 
  vapor (flash steam reciclado) 50%, consumo eléctrico 1 kWh·tEFB⁻¹. 
  Fuente: J. A. Voogt et al. (2021). Distinto del pretratamiento mecánico (Tabla 11, 
  secador rotatorio, Ocampo Batlle et al. 2020, Escenario 1) — no confundir: el térmico 
  aumenta biodegradabilidad del EFB antes de digestión anaeróbica; el mecánico solo 
  reduce humedad para combustión.
- **Producción de metano tras pretratamiento térmico de EFB (Tabla 15):** se distinguen 
  dos conjuntos de parámetros:
  - *Determinado experimentalmente* (medido directamente sobre EFB pretratado, sin 
    valores separados para Efluente): masa seca 44%, humedad 56%, remoción de carga 
    orgánica 66%, producción de biogás 475 m³·t⁻¹ materia orgánica, incremento de 
    producción de biogás 36% (vs. EFB sin pretratar), contenido de CH4 54%.
  - *Suposiciones de diseño conceptual* (valores de diseño, separados por Efluente y 
    EFB): remoción de carga orgánica 85%/73%, producción de biogás 538/523 
    m³·tMO-in⁻¹ y 39/219 m³·tMS⁻¹, contenido de CH4 65%/54% (Efluente/EFB). Para EFB 
    se incluye además un supuesto de "alta remoción de carga orgánica" (10%) como 
    escenario de diseño más conservador.
  - Fuente: J. A. Voogt et al. (2021).
  - **Decisión metodológica (resuelto):** se usa el conjunto de **suposiciones de 
    diseño conceptual** como parámetro de entrada del modelo Pyomo para el Escenario 2, 
    ya que permite modelar de forma consistente el aporte tanto del efluente (POME) 
    como del EFB pretratado dentro del mismo reactor de biogás — el conjunto 
    experimental, aunque con mayor respaldo empírico directo, solo cubre EFB y dejaría 
    sin parametrizar la fracción de POME. Señalar esta elección como supuesto de diseño 
    (no medición directa) en la sección de limitaciones del artículo.

## 16. Enfoque de modelado (a partir de estos datos limpios)

- Modelo de optimización en **Python/Pyomo**, formulado como LP/MILP según la fase (ver plan de trabajo), usando los datos limpios de este documento como parámetros de entrada.
- Selección de la mejor configuración mediante marco de sostenibilidad multicriterio (técnico, económico, ambiental, social) aplicado sobre los resultados del modelo.

## 17. Modelo Pyomo — Fase 1, línea base, Planta A (validación de balance)

- **Objetivo de la Fase 1:** no optimizar — verificar que el balance de energía térmica (caldera) y el balance eléctrico por fuente (biomasa + red nacional + diésel) son consistentes con los datos medidos en campo. Es una prueba de concepto antes de escalar a las 6 plantas y antes de introducir variables de decisión reales (Fase 2).
- **Estructura del modelo (`model = pyo.ConcreteModel`):**
  - Parámetros fijos (medidos): flujo de vapor, energía de combustible, eficiencia de caldera (Sección 7), y las 3 fuentes de electricidad + consumo total (Sección 8.1).
  - Variables: energía térmica útil del vapor, y electricidad por cada una de las 3 fuentes — en esta fase quedan completamente determinadas por las restricciones (no hay grados de libertad).
  - Restricciones: (1) balance térmico = eficiencia × energía combustible; (2)-(4) cada fuente eléctrica igual a su valor medido; (5) restricción de cierre — suma de las 3 fuentes = consumo eléctrico total.
  - Función objetivo *dummy* (`expr=1`) — no aplica optimización real en esta fase, solo se usa el solver para verificar factibilidad del sistema de restricciones.
- **Requisito de entorno — solver GLPK:** Pyomo formula el modelo pero necesita un solver externo (ejecutable) para resolverlo. Se instaló GLPK vía `conda install -c conda-forge glpk` (Anaconda, Windows) — **nota para reproducibilidad:** el ejecutable `glpsol` debe estar disponible en el PATH del sistema; instalarlo por conda evita configurar el PATH manualmente. Verificar con `glpsol --version` en la terminal, y reiniciar el kernel de Jupyter después de instalar (el kernel no detecta software nuevo del sistema hasta reiniciarse).
- **Resultado (Planta A, línea base):** `resultado.solver.termination_condition` → **optimal**, confirmando que el sistema de restricciones es factible y consistente:
  - Energía térmica útil (vapor): 9,626.7 kWth
  - Electricidad autogenerada (biomasa): 2,440,092.0 kWh/año
  - Electricidad de red nacional: 609,714.6 kWh/año
  - Electricidad de diésel: 33,924.4 kWh/año
  - Consumo eléctrico total (verificación): 3,083,731.0 kWh/año — coincide con la suma de las 3 fuentes, cerrando el balance.
- **Interpretación metodológica:** el estado "optimal" en esta fase no debe interpretarse como un resultado de optimización — es la confirmación de que los datos limpios de Secciones 1, 6, 7 y 8.1 son internamente consistentes y pueden usarse como base confiable para los Escenarios 1 y 2 (Secciones 10-11), donde sí habrá grados de libertad reales (variables de decisión) y una función objetivo con sentido físico (maximizar excedente eléctrico).

---

*Última actualización: validado el modelo Pyomo de Fase 1 para línea base (Planta A) — balance térmico y eléctrico cierran correctamente (`optimal`), usando GLPK como solver (instalado vía conda-forge). Pendiente: ensamblar el modelo Pyomo de Escenario 1 (Sección 10, turbina extracción-condensación) y Escenario 2 (Sección 11, turbina contrapresión + biogás) para Planta A; luego escalar a las 6 plantas; determinar el flujo de material inerte/digestato del reactor de biogás.*

## 18. Modelo Pyomo — Escenario 1, Bloques 1-3 (biomasa, caldera, pretratamiento de EFB)

### 18.1 Corrección del LHV de la biomasa (hoja `Biomass`, Sección 2)

- **Hallazgo:** el LHV reportado en el Excel original resta el calor latente de vaporización del agua con un factor ~1000 veces menor al físico (≈2.44 kJ/kg en vez de 2,440 kJ/kg) — error de unidades, del mismo tipo que el ya identificado en el factor de CH4 de `EmisionesCO2` (Sección 6). El error crece con la humedad de cada material (mayor humedad → mayor subestimación del efecto de vaporización → LHV reportado sobreestimado).
- **Verificación:** se reconstruyó la fórmula estándar de ingeniería `LHV_húmedo = HHV_seco·(1-w) − L·[w + 9·H_seco·(1-w)]` (L = 2,440 kJ/kg) a partir de los 3 puntos de humedad disponibles para EFB (65%/50%/10%), confirmando el patrón de error de forma consistente en las 3 variantes.
- **Corrección aplicada** a las 5 variantes de biomasa (recalculado en `df_biomasa`, Sección 2):

  | Material | LHV original (Excel) | LHV corregido | Diferencia |
  |---|---|---|---|
  | EFB (65% hum.) | 6,425.1 kJ/kg | 4,373.9 kJ/kg | +46.9% |
  | Pressed EFB (50%) | 9,179.8 kJ/kg | 7,294.1 kJ/kg | +25.9% |
  | Dry EFB (10%) | 16,525.6 kJ/kg | 15,081.4 kJ/kg | +9.6% |
  | Fiber (35%) | 12,496.6 kJ/kg | 10,772.2 kJ/kg | +16.0% |
  | PKS (15%) | 16,240.6 kJ/kg | 14,821.4 kJ/kg | +9.6% |

- **Impacto:** este LHV corregido se usa en toda la Sección 10 (energía de biomasa a caldera, Escenario 1) y deberá usarse también en el Escenario 2 (Sección 11) — cualquier cálculo de energía de combustión previo que haya usado el LHV original queda invalidado y debe recalcularse.

### 18.2 Disponibilidad de biomasa sólida (Escenario 1)

- **Fuente de flujos:** hoja `Scenarios1` (filas Excel 19-21: Cuesco, Fibra, Raquís/EFB), derivados del balance de masa de la hoja `Eficiencia` — dato de entrada, no recalculado en esta etapa.
- **Nota de trazabilidad importante:** se descartó usar la hoja `Scenario 1` (diagrama de flujo oculto, con espacio en el nombre) como fuente o respaldo de datos — el autor confirmó que esos diagramas son solo ilustrativos, calculados para una planta promedio genérica de 30 tRFF/h representativa del contexto colombiano, no para las 6 plantas del estudio. Además, se detectó que ese diagrama reutiliza el mismo LHV con el bug de la Sección 18.1 (el valor "Enthalpy" de su fila "EFB dried" coincide exactamente con el LHV erróneo de Dry EFB), confirmando que no debe usarse como fuente independiente de validación.

### 18.3 Pretratamiento mecánico del EFB (Tabla 11, Sección 6.2) — aplicado por planta

- El Raquís (EFB) entra al secador a 50% de humedad (equivalente a la categoría "Pressed EFB" de la hoja `Biomass`) y sale a 15% — parámetros ya definidos en la Sección 6.2 (`PARAM_PRETRATAMIENTO_MECANICO_EFB`).
- Se calculó el LHV del EFB ya seco (15% humedad) con la fórmula corregida de la Sección 18.1: **14,108.0 kJ/kg**.
- El secador **no usa electricidad para evaporar el agua** — usa calor residual de los gases de combustión de caldera (215°C). La electricidad (19 kWh/t agua extraída) es solo para la parte mecánica (motores, ventiladores del tambor rotatorio).
- Resultados por planta (energía total de biomasa a caldera tras pretratar el EFB, y electricidad consumida por el secador):

  | Planta | Energía biomasa total (kWth) | Electricidad secador (kWh/h) |
  |---|---|---|
  | A | 35,257.3 | 57.0 |
  | B | 42,493.8 | 70.4 |
  | C | 32,795.5 | 53.7 |
  | D | 24,828.0 | 34.9 |
  | E | 33,098.0 | 57.1 |
  | F | 23,206.7 | 33.4 |

- Con eficiencia de caldera 85% (Tabla 6), el vapor útil resultante: Planta A = 29,968.7 kWth (y proporcionalmente para las demás plantas).

### 18.4 Verificación de calor disponible en gases de combustión para el secador

- **Objetivo:** confirmar si el calor de los gases de combustión (entre 215°C y una temperatura de salida mínima de 120°C, límite práctico para evitar condensación ácida) alcanza para cubrir la demanda térmica de vaporización del agua extraída del EFB (agua extraída × 2,691.1 kJ/kg, parámetro ya definido en la Sección 6.2).
- **Método:** cálculo estequiométrico de combustión a partir de la composición C/H/O/N/S ponderada de la biomasa (Cuesco + Fibra + EFB pretratado), con exceso de aire de **30% (supuesto de literatura genérica — Van Loo & Koppejan, 2008; Basu, 2018)**, no de la fuente específica del pretratamiento (Ocampo Batlle et al., 2020).
- **Resultado — el calor disponible NO alcanza a cubrir la demanda en ninguna de las 6 plantas**, con un déficit de 5-23% según la planta:

  | Planta | Disponible (kWth) | Demanda secador (kWth) | Déficit |
  |---|---|---|---|
  | A | 1,846 | 2,244 | 18% |
  | B | 2,234 | 2,770 | 19% |
  | C | 1,723 | 2,115 | 19% |
  | D | 1,305 | 1,374 | 5% |
  | E | 1,741 | 2,248 | 23% |
  | F | 1,216 | 1,314 | 7.5% |

- **Limitación pendiente (importante para Métodos y Discusión):** el resultado es sensible al supuesto de exceso de aire (se usó 30%, valor genérico de literatura de calderas de biomasa). Se intentó verificar el valor específico reportado por Ocampo Batlle et al. (2020) — fuente original del pretratamiento mecánico (Tabla 11) — pero no se logró acceder al dato exacto (artículo de pago, resúmenes indexados no lo reportan). **Pendiente:** revisar el PDF completo del artículo (si se tiene acceso institucional) para confirmar o ajustar el exceso de aire usado, y correr un análisis de sensibilidad (rango 20-40%) antes de dar el resultado de factibilidad como definitivo. Mientras tanto, se documenta como un déficit marginal (5-23%) que podría revertirse con datos más específicos, y no como una conclusión cerrada de infactibilidad del secado con calor residual.

---

*Última actualización: corregido el LHV de la biomasa (bug de unidades en calor latente, Sección 18.1); validado el pretratamiento mecánico del EFB por planta (Sección 18.3); ejecutada verificación de calor de gases de combustión para el secador — déficit de 5-23% bajo supuesto de exceso de aire de literatura genérica (30%), pendiente confirmar valor específico de Ocampo Batlle et al. (2020). Próximo paso: Bloque 4 de la Sección 10 — turbina de extracción-condensación (Tabla 6).*

## 19. Modelo Pyomo — Escenario 1, Bloques 4-6 (balance de vapor, turbina, excedente eléctrico)

### 19.1 Balance de masa de vapor (producción caldera vs. demanda del proceso)

- **Demanda de extracción (proceso):** se compone de (a) esterilización continua y clarificación dinámica (Tabla 10, dato directo en kg vapor/tRFF — no requieren conversión de unidades) más (b) el resto del proceso (desfrutado, digestión y prensado, palmistería, almacenamiento, extracción de palmiste, calentamiento de agua, planta de tratamiento de agua — Sección 6, reportado en kWth), convertido a kg/h de vapor bajo el supuesto de que el condensado regresa como líquido saturado a 5 bar.
- **Justificación del supuesto de condensado:** confirmado por el autor que estas etapas usan serpentines/radiadores (intercambio indirecto, circuito cerrado) — el supuesto de condensado saturado recuperable es físicamente apropiado para estas etapas.
- **Excepción importante — esterilización continua:** al ser un proceso atmosférico (1 bar, sistema abierto), parte del vapor se pierde por evaporación directa y no regresa como condensado; la fracción que sí condensa arrastra trazas de aceite y se dirige a digestión y prensado (no de vuelta a la caldera). Esto **no afecta el cálculo de extracción de la turbina** (que usa directamente la tasa de Tabla 10, ya en kg/tRFF), pero **sí es relevante para un balance de agua de reposición de caldera** — pendiente de incorporar en una fase posterior del modelo.
- **Resultados del balance por planta** (kg/h): producción entre 25,167 (Planta F) y 46,084 (Planta B); extracción entre 13,642 y 26,590; condensación (remanente a generación eléctrica) entre 10,406 y 19,494 — factible en las 6 plantas.
- **Nota de contraste:** el consumo total de vapor de proceso resultante (~684 kg/tRFF promedio) es mayor al rango típico de esterilización convencional (400-500 kg/tRFF) — consistente con que la esterilización continua consume más vapor que la convencional (ya documentado en Sección 15), aunque parte de la diferencia también podría deberse al supuesto de retorno de condensado adoptado aquí. Señalar como observación metodológica, no como error.

### 19.2 Corrección de bug: entalpía del agua de alimentación (Escenario 1)

- **Hallazgo:** la función `entalpia_agua_alimentacion(T_C, P_bar=1.0)` (definida en Sección 7 para línea base) usa 1 bar por defecto — válido en línea base porque las temperaturas de agua de alimentación (80-95°C) están por debajo de la saturación a 1 bar. Pero en el Escenario 1, el agua de alimentación está a **129°C** (Tabla 6) — por encima de la saturación a 1 bar (~99.6°C) — por lo que evaluarla a 1 bar la calcula como **vapor**, no como líquido comprimido.
- **Detección:** el error se identificó por una prueba de sentido físico simple — el primer cálculo daba una relación vapor:fruto de 5.7:1 (170,679 kg vapor/h para 30,000 kg fruto/h en Planta A), muy por encima del rango físicamente esperado (0.3-1.0). 
- **Corrección:** evaluar el agua de alimentación a la presión de la caldera (48 bar), no a 1 bar por defecto. Tras la corrección, la relación vapor:fruto quedó entre 0.84-1.27 según planta — rango razonable.
- **Recomendación:** revisar si esta misma función se reutiliza en el Escenario 2 (Sección 11) con una temperatura de agua de alimentación distinta a la de línea base, y pasar explícitamente el parámetro `P_bar` correcto en cada caso, en vez de depender del valor por defecto.

### 19.3 Turbina de extracción-condensación (Tabla 6) — planteamiento corregido

- **Primer intento (erróneo):** se trató el estado de extracción (5 bar/159°C) como un resultado a derivar aplicando la eficiencia isentrópica (77%) a la expansión desde 48 bar/470°C. Esto dio una temperatura de extracción calculada de 229.8°C, muy alejada del valor de diseño de la tesis (159°C).
- **Corrección conceptual:** 5 bar/159°C es una **condición de diseño ya especificada** en la Tabla 6 (el punto de extracción fijado por el diseño de la turbina para alimentar el proceso), no algo que deba derivarse con eficiencia isentrópica. El planteamiento correcto:
  - Estado de extracción (h1): se toma **directamente** de la condición de diseño (5 bar/159°C).
  - Eficiencia isentrópica (77%): se aplica a la **expansión completa** (48 bar/470°C → 0.22 bar), usando la entropía de entrada (s0), para obtener el estado de condensación (h2) de forma termodinámicamente consistente.
  - Potencia = (masa total × salto entálpico hasta extracción) + (masa a condensación × salto entálpico de extracción a condensación).
- **Nota epistemológica sobre la validación de temperatura de condensación (62°C):** se confirmó que el resultado calculado coincide con el valor de la tesis (62.1°C vs. 62°C), pero esta coincidencia **no es una validación fuerte** de la eficiencia isentrópica en sí — a 0.22 bar, cualquier estado de vapor húmedo (mezcla líquido-vapor) da automáticamente esa temperatura de saturación, independientemente de la calidad del vapor. Lo que sí confirma es que el estado de salida cae dentro de la zona de mezcla (físicamente esperado en un condensador), no una validación numérica independiente de la eficiencia. Documentar esta distinción para no sobre-interpretar la validación en el artículo.

### 19.4 Resultado — excedente eléctrico neto, Escenario 1 (por planta)

| Planta | Generación turbina neta (kW) | Consumo eléctrico Esc. 1 (kW) | Excedente (kW) | Eficiencia global biomasa→electricidad | Excedente (kWh/tRFF) |
|---|---|---|---|---|---|
| A | 6,005 | 589 | 5,416 | 15.4% | 180.5 |
| B | 7,143 | 762 | 6,381 | 15.0% | 159.5 |
| C | 5,428 | 582 | 4,847 | 14.8% | 161.6 |
| D | 4,124 | 460 | 3,664 | 14.8% | 152.7 |
| E | 5,646 | 591 | 5,055 | 15.3% | 168.5 |
| F | 3,946 | 387 | 3,559 | 15.3% | 177.9 |

- **Consumo eléctrico del Escenario 1:** mismo criterio que el vapor — se resta el consumo eléctrico de las etapas viejas de esterilización/clarificación (Sección 6) y se suman las nuevas (esterilización continua 1.95 kWh/tRFF y clarificación dinámica 15 kWh/tRFF, Tabla 10) más el consumo del secador mecánico de EFB (Sección 18.3).
- **Verificación de sentido físico:** la eficiencia global biomasa→electricidad (14.8-15.4%) cae dentro del rango típico reportado en literatura para turbinas de extracción-condensación en cogeneración con biomasa (~15-25%), y el excedente por tonelada de RFF (153-181 kWh/tRFF) es un orden de magnitud razonable para esta configuración — no hay señales de error en el resultado agregado.

---

*Última actualización: completado el flujo de cálculo del Escenario 1 (Bloques 1-6: disponibilidad de biomasa, pretratamiento de EFB, caldera, balance de vapor, turbina de extracción-condensación, excedente eléctrico neto) para las 6 plantas. Corregidos 2 bugs en el camino (entalpía de agua de alimentación a presión incorrecta; planteamiento erróneo del estado de extracción de la turbina). Pendiente: envolver el flujo completo en un `ConcreteModel` de Pyomo (Bloque 7, análogo a la Sección 9 de línea base) y avanzar al Escenario 2 (turbina de contrapresión + biogás, Sección 11).*

## 20. Modelo Pyomo — Escenario 1, Bloques 7-8 (biogás de POME y excedente total)

### 20.1 Generación de biogás a partir de POME

- **Fuente de datos:** flujo de efluente/POME (hoja `Scenarios1`, fila Excel 38, L/h por planta) y DQO de entrada (fila Excel 40, mg/L — mismo dato ya usado en `DQO_ENTRADA_mg_L`, Sección 6.4).
- **Validación cruzada de parámetros (mismo enfoque usado con el LHV, Sección 18.1):** se comparó la cadena de cálculo de biogás ya existente en `Scenarios1` (filas 34-44, no usada directamente como fuente de resultados, solo para validar supuestos) contra el parámetro `disponibilidad_biogas_POME_Nm3_kgDQO = 0.35` (Rahayu et al., 2015) ya definido en `PARAM_DIGESTION_ANAEROBICA`. Hallazgos:
  - El valor 0.35 **ya corresponde a Nm³ de CH4 directamente** (no de biogás total) — coincide con el valor teórico estequiométrico estándar de conversión DQO→metano (0.35 L CH4/g DQO removido a condiciones normales), confirmado al reproducir el "potencial de generación de metano" de la hoja con ~98% de coincidencia (la pequeña diferencia es consistente con una eficiencia de remoción de DQO cercana al 100%, no con un factor de %CH4 adicional). **Esto simplifica el cálculo: no hace falta un factor adicional de %CH4 en el biogás.**
  - El poder calorífico inferior del metano implícito en la hoja (9.94 kWh/Nm³ ≈ 35.8 MJ/Nm³) coincide con el valor físico estándar del CH4 puro — se usa como constante física, no como dato dependiente del Excel.
  - La eficiencia bruta del generador (motor de combustión interna a biogás) implícita en la hoja es **40.0% exacto** (idéntica en las plantas verificadas) — valor redondo, dentro del rango típico de literatura para motores de biogás (35-42%), adoptado como supuesto de diseño.
  - El factor "neto/bruto" de generación implícito en la hoja (80.0% exacto) **no se pudo explicar** con los parámetros ya documentados (no coincide con aplicar el autoconsumo de 0.227 kWh/Nm³ CH4, que solo explicaría ~5-6% de reducción, no 20%) — **se descartó por falta de trazabilidad** (mismo criterio que con otros datos sin fuente clara del Excel original) y se usó en su lugar el autoconsumo ya documentado con fuente (Rahayu et al., 2015).
- **Resultados por planta** (generación neta de biogás, kW):

  | Planta | Metano (Nm³/h) | Generación bruta (kW) | Autoconsumo (kW) | Generación neta (kW) |
  |---|---|---|---|---|
  | A | 469.3 | 1,866.0 | 106.5 | 1,759.5 |
  | B | 821.3 | 3,265.6 | 186.4 | 3,079.2 |
  | C | 576.9 | 2,293.8 | 131.0 | 2,162.8 |
  | D | 619.8 | 2,464.3 | 140.7 | 2,323.6 |
  | E | 613.2 | 2,438.2 | 139.2 | 2,299.0 |
  | F | 398.8 | 1,585.8 | 90.5 | 1,495.3 |

### 20.2 Excedente eléctrico total del Escenario 1 (turbina + biogás)

| Planta | Turbina (kW) | Biogás POME (kW) | **Total (kW)** | % del total aportado por biogás |
|---|---|---|---|---|
| A | 5,416 | 1,759.5 | **7,175.3** | 24.5% |
| B | 6,381 | 3,079.2 | **9,460.0** | 32.6% |
| C | 4,847 | 2,162.8 | **7,009.6** | 30.9% |
| D | 3,664 | 2,323.6 | **5,987.5** | 38.8% |
| E | 5,055 | 2,299.0 | **7,354.0** | 31.3% |
| F | 3,559 | 1,495.3 | **5,054.2** | 29.6% |

- **Observación para la discusión del artículo:** el biogás de POME aporta entre 24.5% y 38.8% del excedente eléctrico total del Escenario 1 según la planta — una contribución significativa, y con la ventaja de ser un flujo constante todo el año (a diferencia de la biomasa sólida, sujeta a la estacionalidad documentada en la Sección 12), lo que podría discutirse como un complemento que reduce la necesidad de almacenamiento de biomasa frente a depender solo de la turbina.

---

*Última actualización: completado el Escenario 1 en su totalidad (Bloques 1-8: biomasa, pretratamiento EFB, caldera, vapor, turbina, excedente eléctrico de turbina, biogás de POME, excedente eléctrico total) para las 6 plantas. Próximo paso: envolver el flujo completo en un `ConcreteModel` de Pyomo (Bloque 9, análogo a la Sección 9 de línea base) y/o avanzar al Escenario 2 (turbina de contrapresión + biogás con POME y EFB pretratado térmicamente, Sección 11).*

## 21. Plan de Fase 2 — selección de tamaño comercial de turbina (pendiente, no implementado aún)

- **Motivación:** el Bloque 9 (`ConcreteModel` de Escenario 1, Planta A) da una potencia bruta de turbina "exacta" (7,517 kW) que no corresponde a ningún tamaño comercial real (los fabricantes ofrecen tamaños estándar discretos). En Fase 1 esto no es un problema porque el modelo solo valida consistencia (ver nota metodológica sobre la función objetivo dummy, más abajo), pero es una limitación a resolver antes de presentar resultados de dimensionamiento en el artículo.
- **Dos enfoques posibles para Fase 2 (a decidir más adelante):**
  1. **Turbina de capacidad fija (más simple):** fijar la potencia de la turbina a un tamaño comercial (parámetro, no resultado) y convertir la restricción de potencia de `==` a `<=`. Esto abre la pregunta de qué hacer con la biomasa que ya no cabe en el ciclo de vapor (¿venta como pellets, otro uso?) — se vuelve una variable de decisión genuina de distribución de biomasa.
  2. **Selección discreta de turbina (MILP):** dar un catálogo de tamaños comerciales disponibles (ej. 5,000/6,000/7,000/8,000 kW) con una variable binaria de selección, y dejar que el solver elija el tamaño que maximice el excedente eléctrico (o una métrica económica, si se incorpora CAPEX por tamaño). Este es el primer caso de uso real donde la función objetivo (no dummy) y las variables de decisión genuinas de la Fase 2 entran en juego.
- **Nota pedagógica registrada en el chat (útil para la sección de Métodos):** se aclaró la diferencia entre lo que hace el solver en Fase 1 (verificación de factibilidad de un sistema de ecuaciones con una función objetivo dummy `expr=1`, sin verdadera optimización — "optimal" aquí es sinónimo de "factible") vs. lo que hará en Fase 2 (elegir entre múltiples soluciones factibles la que maximice una función objetivo real, con variables de decisión no completamente determinadas por igualdades).

---

*Última actualización: formalizado el flujo completo del Escenario 1 (Planta A) en un `ConcreteModel` de Pyomo (Bloque 9) — validado `optimal`/factible, coincide exacto con los cálculos manuales previos. Documentado el plan de Fase 2 para selección de tamaño comercial de turbina (Sección 21, pendiente de implementar). Próximos pasos posibles: (a) escalar el `ConcreteModel` de Escenario 1 a las 6 plantas, (b) iniciar el Escenario 2 (turbina de contrapresión + biogás con POME y EFB pretratado térmicamente, Sección 11).*

## 22. Modelo Pyomo — Escenario 2 completo (turbina de contrapresión + biogás con POME y EFB pretratado)

### 22.1 Dos bugs adicionales encontrados y corregidos (afectan Escenarios 1 y 2)

- **Bug — consumo eléctrico de clarificación dinámica (Tabla 10):** el valor usado (`consumo_electricidad_kWh_tRFF = 15`) era un **error de decimal** — el valor correcto, confirmado contra la tesis, es **1.5 kWh/tRFF**. Se detectó al contrastar contra la fuente primaria (Fernández et al., 2016, *Palmas* 37(3)): el artículo reporta que la clarificación dinámica **reduce** la potencia instalada de la sección de clarificación (100→45 kW en el caso de estudio real), mientras que con el valor de 15 kWh/tRFF el modelo daba ~450 kW *solo* para esa etapa en una planta de 30 t/h — 10 veces la potencia instalada real reportada en el caso de estudio. Corregido en `PARAM_CLARIFICACION_DINAMICA` (Sección 6.1). Afecta el consumo eléctrico de ambos escenarios.
- **Bug — escala de la columna "Electrica" en `df_demanda_por_etapa` (Sección 6, hoja `Eficiencia`):** los valores de demanda eléctrica por etapa estaban en **kW específicos (por t/h de capacidad de planta)**, no en kW absolutos, a pesar de que el header del Excel decía `(kWe)` sin aclarar que era específico. Detectado por sentido físico: la suma de todas las etapas (fila "Total" del propio Excel) daba solo ~25.75 kW para Planta A — implausible para una planta industrial de 30 t/h (confirmado por el autor: el rango real típico es 600-800 kW). Al multiplicar por la capacidad de planta (30 t/h × 25.75 = 772.5 kW), el resultado cae exactamente en ese rango. **Nota importante:** la columna "Termica" de la misma tabla NO tiene este problema — ya está validada como absoluta (Sección 8, coincide exacto con `Scenarios1`). Corregido multiplicando la columna Electrica por la capacidad de planta, en la Sección 6, inmediatamente después de construir `df_demanda_por_etapa` (se propaga automáticamente a los Bloques 6 de ambos escenarios sin tocar más código).
- **Resultados actualizados tras ambas correcciones:**
  - Escenario 1 — excedente eléctrico total (turbina + biogás): A=6,906.9, B=9,455.1, C=6,852.3, D=5,898.2, E=7,012.4, F=5,052.3 kW.
  - Escenario 2 — excedente de la turbina sola (antes de sumar biogás): A=61, B=322, C=100, D=172, **E=-123 (negativo)**, F=271 kW. La turbina de contrapresión, al ser mucho más pequeña, apenas cubre (o no cubre, caso Planta E) su propio consumo eléctrico de proceso — hallazgo consistente con la experiencia real de plantas pequeñas donde estos sistemas ni siquiera cubren su autoconsumo.

### 22.2 Parámetros de caldera del Escenario 2 (Tabla 16, Booneimsri et al., 2018)

- Presión de caldera: 21 bar. Eficiencia térmica: 70%. Temperatura de agua de alimentación: 100°C.
- **Inconsistencia física detectada y resuelta:** la tesis reporta "Temperatura vapor de agua" = 90°C a 21 bar — físicamente imposible (la saturación a 21 bar es ~215°C; a 90°C sería líquido, no vapor). Se descartó ese dato y se adoptó **230°C como supuesto de trabajo** (punto medio del rango típico de vapor ligeramente sobrecalentado, 220-240°C, confirmado por el autor) — **pendiente de confirmar con la fuente original** si hay un valor más preciso.
- **Entalpía del agua de alimentación:** la tesis reporta 445 kJ/kg a 100°C; el cálculo con IAPWS-IF97 a 100°C/21 bar da ~420.6 kJ/kg (diferencia ~5.7%). Se optó por usar IAPWS97 por consistencia metodológica con el resto del modelo (decisión del autor).

### 22.3 Balance de vapor — cambio de tecnología de esterilización en Escenario 2

- **Hallazgo inicial:** con esterilización continua (Tabla 10, igual que Escenario 1) + pretratamiento térmico del EFB, la demanda de vapor del proceso **superaba la producción disponible en las 6 plantas** (déficit de 5-19%, empeorando a 5-30% al sumar el vapor desviado para el reactor de pretratamiento térmico antes de la turbina).
- **Decisión de diseño (a criterio del autor, con justificación de costos):** para el Escenario 2 se **revierte a esterilización convencional** (en vez de continua) — evita instalar equipos adicionales de mantenimiento/inversión — y se **reutiliza el vapor recuperado del pretratamiento térmico** (50% de recuperación, Tabla 14) reinyectándolo al proceso en vez de descartarlo. Con ambos ajustes, **5 de 6 plantas cierran el balance** (A, B, D, E, F ✅); solo **Planta C queda con déficit residual** (~2,142 kg/h) — aceptado como limitación de escala, consistente con la experiencia del autor de que plantas pequeñas no siempre logran instalar sistemas de contrapresión con generación completa.
- **Fuente del dato de esterilización convencional:** flujo real medido por planta (hoja `Eficiencia`, fila Excel 14, `'Vapor de esterilización' 'kgvapor∙h-1'`) — dato de campo, no una conversión con supuestos.
- **Nota metodológica — clarificación dinámica se mantiene en ambos escenarios** (a diferencia de la esterilización): reduce consumo de vapor sin agregar carga eléctrica desproporcionada (tras corregir el bug de la Sección 22.1).
- **Vapor desviado para pretratamiento térmico del EFB:** se asume que se toma directamente de la salida de caldera (throttled desde 21 bar), antes de la turbina — reduce la masa disponible para generar electricidad. Demanda neta (tras 50% de recuperación) = 0.15 t vapor/t EFB crudo.

### 22.4 Turbina de contrapresión

- Expansión única (21 bar/230°C → 5 bar, misma presión de proceso usada en el balance de vapor), con eficiencia isentrópica de contrapresión (75%, Tabla 6) aplicada a la expansión completa. Reutiliza eficiencia mecánica (98%) y eléctrica del generador (95%) de la Tabla 6 — no hay dato distinto documentado para el tren de generación de este sistema.
- **Validación fuerte de sentido físico:** la potencia bruta calculada (745-1,195 kW según planta) cae **exactamente** dentro del rango que el autor confirmó como típico de la práctica real para turbinas de contrapresión en plantas pequeñas/medianas (800-1,000 kW) — sin haber forzado ningún parámetro para lograrlo. Buena señal de que la cadena completa de supuestos (caldera, balance de vapor, esterilización convencional, recuperación de pretratamiento) está bien planteada.
- Calidad del vapor de escape: ~0.95 (ligeramente húmedo) — físicamente coherente para una turbina de contrapresión.

### 22.5 Biogás — POME + EFB pretratado térmicamente (Tabla 15, "diseño conceptual")

- A diferencia del Escenario 1 (que usa la fórmula simple de Rahayu et al., 0.35 Nm³ CH4/kg DQO, ya validada), el Escenario 2 usa el conjunto **"diseño conceptual"** de la Tabla 15 (Voogt et al., 2021), que da tasas de producción de biogás distintas para Efluente (POME) y EFB, expresadas en m³ biogás por tonelada de materia seca (tMS): 39 para Efluente, 219 para EFB — con contenido de CH4 de 65% y 54% respectivamente.
- **Balance de masa del pretratamiento térmico del EFB:** se calculó con el mismo principio que el pretratamiento mecánico (Sección 6.2) — materia seca conservada, humedad 65% (EFB crudo, hoja `Biomass`) → 56% (EFB pretratado, Tabla 15 "determinado experimentalmente"). Esto da la masa de EFB pretratado que entra al biodigestor.
- **Supuesto adicional:** densidad del efluente (POME) ≈ 1 kg/L, para convertir el flujo de L/h a kg/h y aplicar el % de materia seca (9% para Efluente).
- **Resultado — el EFB pretratado aporta ~7 veces más CH4 que el efluente solo** (301.7 vs. 41.1 Nm³/h en Planta A) — confirma que valió la pena desviar el EFB hacia biogás en este escenario.
- **Investigación de reconciliación con la hoja `Scenarios2` del Excel y el paper fuente (Voogt et al., 2021, EU BC&E):** se encontraron discrepancias significativas entre nuestro cálculo y los resultados que ya existían en `Scenarios2` (excedente total: nuestro ~1,346 kW vs. Excel ~3,784 kW, Planta A). Investigación:
  - **Arquitectura del sistema confirmada como correcta:** el paper de Voogt et al. describe un "Case 2b" donde EFB + Fibra (MF) + POME van *todos* a digestión anaeróbica (sin combustión directa de biomasa), con vapor generado en un calderín de biogás — arquitectura **distinta** a la del Escenario 2 de la tesis (que sí quema fibra+cuesco en caldera con turbina, y solo desvía EFB+POME a biogás). El autor confirmó que su Escenario 2 es un diseño **híbrido propio** que solo tomó parámetros puntuales de Voogt et al. (Tablas 14-15), no la arquitectura completa — por lo tanto, el hecho de no replicar el "Case 2b" del paper no es un error, es una decisión de diseño ya tomada.
  - **Eficiencia de caldera implícita en `Scenarios2` = 85%** (idéntica a la Tabla 6 del Escenario 1) — sospechosamente igual, probablemente una referencia de fórmula copiada de la hoja del Escenario 1 sin ajustar. Se descartó a favor de la Tabla 16 (70%), que es la fuente específicamente construida para el sistema de contrapresión. El 60% que reporta Voogt et al. para su propio caso de estudio tampoco aplica directamente (diseño distinto).
  - **Metano del EFB en `Scenarios2` calculado con la fórmula de Thomsen (BMP, ya validada en Sección 6.4) aplicada al EFB *crudo*, no al pretratado** — reverse-engineered con éxito (fracción de sólidos volátiles implícita: 32% del EFB crudo, 91.4% del contenido seco — valores típicos y razonables). Esto da *más* metano (638.0 m³/h) que nuestro cálculo con la Tabla 15 sobre EFB *pretratado* (301.7 m³/h) — **contradictorio con la propia conclusión del paper de Voogt et al.**, que afirma explícitamente que el pretratamiento térmico *aumenta* la digestibilidad y producción de biogás. Se concluye que la hoja `Scenarios2` del Excel probablemente quedó desactualizada (se armó antes de adoptar el pretratamiento térmico + Tabla 15) y **no se usa como referencia** — se mantiene el cálculo con Tabla 15 sobre EFB pretratado.
  - **Conclusión de la investigación:** no se modificó ningún bloque de código a partir de esta comparación — se documenta como evidencia de que el Excel original (`Scenarios2`) tiene inconsistencias internas de las que hay que desconfiar, ya identificadas repetidamente a lo largo del proyecto (LHV, factor CH4, entalpía de agua de alimentación, etc.), y se valida la decisión de reconstruir los cálculos desde cero en vez de reutilizar los resultados de esa hoja — coherente con la política ya establecida en la Sección 7 de estas notas.

### 22.6 Resultado final — Escenario 2 completo (por planta)

| Planta | Turbina (kW) | Biogás POME+EFB (kW) | **Total (kW)** | % aportado por biogás |
|---|---|---|---|---|
| A | 61 | 1,285.2 | **1,346.4** | 95.5% |
| B | 322 | 1,601.9 | **1,924.1** | 83.3% |
| C | 100 | 1,220.0 | **1,319.8** | 92.4% |
| D | 172 | 815.9 | **987.5** | 82.6% |
| E | -123 | 1,287.0 | **1,163.7** | 110.6% (turbina negativa) |
| F | 271 | 765.2 | **1,036.1** | 73.9% |

- **Comparación Escenario 1 vs. Escenario 2:** el Escenario 1 da un excedente 4-7 veces mayor en todas las plantas — resultado esperado, ya que en Escenario 1 toda la biomasa sólida (fibra+cuesco+EFB) pasa por un ciclo de vapor de alta presión con turbina grande, mientras que en Escenario 2 solo fibra+cuesco alimentan una turbina de contrapresión pequeña y el EFB se desvía a una ruta de biogás con menor eficiencia de conversión a electricidad por unidad de energía de entrada.
- **El biogás domina el excedente eléctrico del Escenario 2** (74-111% del total, siendo >100% en Planta E por la turbina negativa) — contraste fuerte con el Escenario 1, donde el biogás aporta una fracción más modesta (25-39%). Buen ángulo de discusión para el artículo.

---

*Última actualización: completado el Escenario 2 en su totalidad (Bloques 1-8), incluyendo dos bugs adicionales corregidos (clarificación dinámica, escala de consumo eléctrico por etapa) que afectan también al Escenario 1. Investigación de reconciliación con la hoja `Scenarios2` del Excel y el paper fuente de Voogt et al. (2021) documentada — se confirma la arquitectura híbrida propia del Escenario 2 y se decide no usar `Scenarios2` como referencia (desactualizada). Próximos pasos: envolver el Escenario 2 en un `ConcreteModel` de Pyomo (análogo al Bloque 9 del Escenario 1); comparación completa de los 3 escenarios (línea base, Escenario 1, Escenario 2); considerar escalar ambos escenarios a un `ConcreteModel` indexado por planta.*

## 23. Corrección — interpretación de "materia orgánica de entrada" (MOin), Tabla 15

### 23.1 El problema

La Tabla 15 (Voogt et al., 2021, "diseño conceptual") da dos tasas alternativas de producción de biogás: **m³ biogás/t de materia seca (tMS)** y **m³ biogás/t de materia orgánica de entrada (tMOin)**. Inicialmente se usó la tasa por tMS (39 para Efluente, 219 para EFB — Sección 22.5), por ser la que se podía calcular directamente con el dato de % de materia seca ya disponible. Sin embargo, el autor notó que el resultado (CH4 de EFB = 301.7 Nm³/h, Planta A) le parecía bajo frente a lo que esperaba.

### 23.2 Investigación y corrección

- Al revisar de nuevo, se determinó que **"MOin" se refiere a sólidos volátiles (SV), no a materia seca total** — confirmado por el autor tras revisar la fuente.
- **Evidencia de respaldo 1 (ya documentada, Sección 22.5):** el reverse-engineering del cálculo de metano de EFB en la hoja `Scenarios2` del Excel (que usa la fórmula de Thomsen/BMP sobre EFB crudo) arrojó una fracción de sólidos volátiles implícita de 91.4% de la materia seca — consistente con el rango típico de biomasa lignocelulósica (85-95%).
- **Evidencia de respaldo 2 (nueva, encontrada al corregir):** el efluente (POME) es la única corriente que aparece calculada en ambos escenarios, por dos metodologías bibliográficas distintas — Rahayu et al. (2015, vía DQO, usado en Escenario 1) y Voogt et al. (2021, vía tMOin, Escenario 2). Con la interpretación **tMS** (incorrecta), ambos métodos daban resultados desfasados por un factor de **11.4x** (41.1 vs. 469.3 Nm³/h CH4, Planta A) — sin sentido físico para la misma corriente. Con la interpretación **VS** (corregida), ambos métodos coinciden dentro de un **8.7%** (509.9 vs. 469.3 Nm³/h) — una diferencia razonable entre dos fuentes bibliográficas distintas, y una validación cruzada sólida de que la corrección es la correcta.
- **Corrección aplicada:** se usa `FRACCION_VS_MATERIA_SECA = 0.90` (redondeado, con evidencia sólida solo para EFB — para Efluente se usa el mismo valor como supuesto de trabajo, **pendiente de confirmar con la fuente original** ya que no hay verificación independiente específica para esa corriente) multiplicando la materia seca antes de aplicar la tasa m³/tMOin (523 para EFB, 538 para Efluente).

### 23.3 Resultado actualizado

| Planta | CH4 Efluente (Nm³/h) | CH4 EFB (Nm³/h) | CH4 total (Nm³/h) | Generación neta biogás (kW) |
|---|---|---|---|---|
| A | 509.9 | 648.5 | 1,158.4 | 4,342.8 |
| B | 679.8 | 800.7 | 1,480.5 | 5,550.3 |
| C | 509.9 | 611.2 | 1,121.0 | 4,202.8 |
| D | 407.9 | 397.1 | 805.0 | 3,018.0 |
| E | 509.9 | 649.6 | 1,159.5 | 4,346.8 |
| F | 339.9 | 379.9 | 719.8 | 2,698.4 |

**Excedente eléctrico total del Escenario 2, actualizado:**

| Planta | Turbina (kW) | Biogás (kW) | **Total (kW)** | Total Esc.2 / Total Esc.1 |
|---|---|---|---|---|
| A | 61 | 4,342.8 | **4,404.1** | 63.8% |
| B | 322 | 5,550.3 | **5,872.6** | 62.1% |
| C | 100 | 4,202.8 | **4,302.5** | 62.8% |
| D | 172 | 3,018.0 | **3,189.6** | 54.1% |
| E | -123 | 4,346.8 | **4,223.4** | 60.2% |
| F | 271 | 2,698.4 | **2,969.3** | 58.8% |

- **Cambio en la narrativa comparativa:** con la corrección, el Escenario 2 pasa de ser un distante segundo lugar (19-24% del Escenario 1) a una alternativa mucho más competitiva (54-64% del Escenario 1) — cambia sustancialmente el ángulo de discusión del artículo. El Escenario 1 sigue siendo superior en las 6 plantas (combustión directa + turbina de extracción-condensación más grande es energéticamente más eficiente que la ruta de digestión anaeróbica), pero la brecha ya no es tan amplia.
- **`ConcreteModel` de Pyomo del Escenario 2 (Bloque 9, Planta A)** actualizado automáticamente al recalcular `biogas_pome_y_efb_esc2()` — validado `optimal`, coincide exacto con el cálculo manual (4,404.1 kW).

---

*Última actualización: corregida la interpretación de "materia orgánica de entrada" (MOin) en la Tabla 15 — de materia seca total a sólidos volátiles (~90% de la materia seca), validado con evidencia cruzada sólida (reverse-engineering del Excel + comparación independiente del cálculo de POME entre Escenario 1 y 2, coincidencia dentro de 8.7%). El excedente eléctrico del Escenario 2 sube sustancialmente (de ~20% a ~55-64% del Escenario 1) — cambia el ángulo comparativo del artículo. Pendiente: confirmar la fracción VS/materia seca para Efluente con la fuente original (solo hay evidencia sólida para EFB). Próximos pasos: tabla/gráfico comparativo de los 3 escenarios; plan de Fase 2 (selección de turbina comercial, Sección 21).*
