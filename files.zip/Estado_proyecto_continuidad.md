# Estado del proyecto — Resumen para continuar en nuevo chat

**Instrucciones de uso:** pega este documento completo como primer mensaje en el chat nuevo, junto con: (1) tu notebook `.ipynb` actualizado, (2) el archivo `Notas_metodologicas_articulo.md`. Con eso, Claude puede retomar exactamente donde íbamos.

---

## Qué es este proyecto

Artículo científico basado en el Capítulo 5 de mi tesis doctoral (valorización energética de biomasa residual de palma de aceite, 6 plantas extractoras del Magdalena, Colombia). Comparo 3 configuraciones: **Línea base**, **Escenario 1** (turbina extracción-condensación) y **Escenario 2** (turbina contrapresión + biogás mejorado), usando un modelo de optimización en **Python/Pyomo** — también es mi proyecto de aprendizaje de modelado energético para fortalecer mi CV.

## Repositorio y archivos

- **GitHub:** `https://github.com/juncal0/valorizacion-biomasa-palma`
- **Notebook principal:** `01_limpieza_datos_capex_emisiones_social.ipynb` (organizado en 11 secciones numeradas con Markdown)
- **Datos crudos:** `Escenarios.xlsx` (NO está en GitHub por confidencialidad de cotizaciones — solo local)
- **Notas metodológicas completas:** `Notas_metodologicas_articulo.md` (documento vivo con TODAS las decisiones, discrepancias resueltas y fuentes citadas — ya va por la Sección 22)

## Flujo de trabajo establecido (importante que Claude lo respete)

1. Cada vez que se agrega código nuevo, indicar en qué sección/bloque del notebook va.
2. Cada hallazgo/decisión metodológica se documenta en `Notas_metodologicas_articulo.md`.
3. Respaldo en Git después de cada avance: `git add .` → `git commit -m "..."` → `git push` (recordar siempre `cd "/c/Users/Legion 5/tesis-articulo"` primero).
4. Cuando algo del Excel es sospechoso (fórmula rota, error de unidad, dato huérfano), se **valida antes de usar** — no se asume.
5. Estoy aprendiendo Python/Jupyter desde cero — explicar pasos con calma, recordar imports necesarios al inicio de cada bloque de código.
6. Antes de aceptar un resultado numérico como bueno, se hace una **prueba de sentido físico** (órdenes de magnitud, comparación con literatura o con la experiencia real del autor) — así se han detectado ~6 bugs reales en el camino (ver más abajo).

## PENDIENTE / próximo paso inmediato

1. **Envolver el Escenario 2 en un `ConcreteModel` de Pyomo** (análogo al Bloque 9 del Escenario 1, Sección 9).
2. **Comparación completa de los 3 escenarios** (línea base, Escenario 1, Escenario 2) — tabla/gráfico consolidado para el artículo.
3. Considerar escalar ambos escenarios (`ConcreteModel`) a las 6 plantas de forma indexada, en vez de repetir el patrón manual planta por planta.
4. **Plan de Fase 2 ya documentado (Sección 21 de las notas), pendiente de implementar:** selección de tamaño comercial de turbina (capacidad fija vs. catálogo con variable binaria/MILP) — surgió porque las potencias calculadas (7,517 kW Escenario 1; 745-1,195 kW Escenario 2) no corresponden a tamaños comerciales reales, aunque el rango del Escenario 2 sí valida contra la práctica real (800-1,000 kW).
5. Determinar el flujo de material inerte/digestato que sale del reactor de biogás (tengo un artículo de referencia para revisar) — relevante para ambos escenarios.
6. Después de Planta A/6 plantas: figuras de balance de masa/energía (usando el módulo de diagramas de Claude), análisis multicriterio de sostenibilidad, redacción del artículo.

## PENDIENTES DE VERIFICACIÓN (no bloquean el avance, pero hay que resolverlos antes de publicar)

- **Temperatura de vapor de caldera del Escenario 2 (Tabla 16):** la tesis reporta 90°C a 21 bar, físicamente inconsistente (saturación ~215°C). Se usa 230°C como supuesto de trabajo (rango típico 220-240°C) — confirmar con la fuente original (Booneimsri et al., 2018).
- **Exceso de aire para el cálculo de gases de combustión del secador de EFB (Escenario 1, Bloque 3):** se usó 30% (literatura genérica) porque no se pudo confirmar el valor específico de Ocampo Batlle et al. (2020) — pendiente si se consigue el PDF completo del artículo.

## YA RESUELTO (no volver a preguntar)

- **Datos limpios:** Datos_Base, Biomass (con LHV corregido — ver más abajo), CAPEX, EmisionesCO2, módulo social (Hoja2), Eficiencia (balance + demanda por etapa + caldera línea base).
- **Modelo Pyomo, Fase 1, Línea base (Sección 9):** balance térmico y eléctrico de Planta A validado con GLPK (`termination_condition: optimal`). Requiere GLPK instalado vía `conda install -c conda-forge glpk`.
- **LHV de biomasa corregido (Sección 2 / Notas Sección 18.1):** el Excel original tenía un bug de unidades en el calor latente de vaporización (~1000x menor al valor físico). Se corrigió con la fórmula estándar `LHV = HHV_seco·(1-w) − 2440·[w + 9·H_seco·(1-w)]`. Afecta EFB, Pressed EFB, Dry EFB, Fiber, PKS.
- **Bugs adicionales corregidos (afectan ambos escenarios, Notas Sección 22.1):**
  - `PARAM_CLARIFICACION_DINAMICA['consumo_electricidad_kWh_tRFF']`: era 15 (error de decimal), corregido a **1.5** — verificado contra Fernández et al. (2016).
  - Columna "Electrica" de `df_demanda_por_etapa` (Sección 6, hoja `Eficiencia`): estaba en valores específicos (kW/t·h⁻¹ de capacidad), no absolutos — se corrige multiplicando por la capacidad de planta, verificado contra rango real típico (600-800 kW) confirmado por el autor.
- **Escenario 1 — flujo completo calculado y validado por planta, incluyendo biogás (Sección 10, Bloques 1-8; Notas Secciones 18-20):**
  - Biomasa (Cuesco/Fibra/Raquís) + pretratamiento mecánico del EFB (Tabla 11) + caldera (Tabla 6, 48 bar/470°C, η=85%) + turbina extracción-condensación (5 bar proceso / 0.22 bar condensación) + biogás de POME (Rahayu et al., 0.35 Nm³ CH4/kgDQO).
  - **Excedente eléctrico total (turbina + biogás), post-correcciones:** A=6,906.9, B=9,455.1, C=6,852.3, D=5,898.2, E=7,012.4, F=5,052.3 kW.
  - Formalizado en `ConcreteModel` de Pyomo (Bloque 9, Planta A) — validado `optimal`, coincide exacto con cálculo manual.
- **Escenario 2 — flujo completo calculado y validado por planta, incluyendo biogás (Sección 11, Bloques 1-8; Notas Sección 22):**
  - Biomasa solo Cuesco+Fibra (EFB retirado, va a biogás) + caldera (Tabla 16, 21 bar/230°C supuesto, η=70%) + **esterilización convencional** (revertida desde continua, por costos — dato real de campo) + reutilización del vapor recuperado del pretratamiento térmico del EFB (Tabla 14) + turbina de contrapresión (75% eficiencia isentrópica, escape a 5 bar) + biogás de POME+EFB pretratado térmicamente (Tabla 15, "diseño conceptual", 39/219 m³ biogás/tMS).
  - **Solo Planta C queda con déficit residual de vapor** (~2,142 kg/h) — aceptado como limitación de escala.
  - **Potencia bruta de turbina (745-1,195 kW) valida fuertemente contra el rango real confirmado por el autor (800-1,000 kW)** — sin haber forzado el ajuste.
  - **Excedente eléctrico de la turbina sola puede ser negativo** (Planta E: -123 kW) — el biogás es indispensable para tener excedente neto positivo en este escenario.
  - **CORREGIDO (Notas Sección 23):** la Tabla 15 tiene 2 tasas alternativas de biogás (m³/tMS y m³/tMOin). Se usó inicialmente tMS, pero se corrigió a tMOin (interpretando MOin = sólidos volátiles, ~90% de materia seca) tras validación cruzada fuerte: el POME calculado por Rahayu et al. (Escenario 1) vs. Voogt et al. (Escenario 2) coincide dentro de 8.7% con la interpretación VS, vs. un desfase de 11.4x con la interpretación tMS (sin sentido físico).
  - **Excedente eléctrico total (post-corrección MOin):** A=4,404.1, B=5,872.6, C=4,302.5, D=3,189.6, E=4,223.4, F=2,969.3 kW — equivale a 54-64% del Escenario 1 (antes de la corrección era solo 19-24%, cambia el ángulo comparativo del artículo).
  - Formalizado en `ConcreteModel` de Pyomo (Bloque 9, Planta A) — validado `optimal`, coincide exacto (4,404.1 kW).
  - **Investigación de reconciliación con `Scenarios2` (Excel) y Voogt et al. (2021):** se encontraron discrepancias grandes con los resultados ya calculados en esa hoja del Excel; se investigó a fondo y se concluyó que `Scenarios2` está desactualizada (usa 85% de eficiencia de caldera en vez de 70% de Tabla 16, y calcula el metano del EFB con la fórmula de Thomsen sobre EFB *crudo* en vez de la Tabla 15 sobre EFB *pretratado* — contradictorio con la propia conclusión del paper de Voogt et al. de que el pretratamiento aumenta la producción de biogás). Se decidió NO usar `Scenarios2` como referencia — se mantienen los cálculos propios.
  - Comparación: Escenario 1 da 4-7 veces más excedente que Escenario 2 en todas las plantas (biomasa completa + turbina grande vs. solo fibra+cuesco + turbina pequeña + más dependencia de biogás).
- **Alcance del modelo:** Fase 1 = validación con capacidad fija (sin optimizar); Fase 2 futura = superestructura con variables de decisión, incluyendo selección de tamaño comercial de turbina (Notas Sección 21). Empezamos con prueba de concepto en Planta A antes de escalar a las 6 plantas (aunque en la práctica ya se calculó Escenario 1 y 2 para las 6 plantas directamente, por ser cálculo directo sin optimización).
- **Restricción activa:** disponibilidad de biomasa (no se puede calcular más energía de la disponible).
- **Función objetivo (Fase 2):** maximizar excedente eléctrico. Sostenibilidad (LCOE, emisiones, social) se evalúa como análisis posterior (multicriterio/Pareto), no dentro de la función objetivo.
- **Escenario 1 (extracción-condensación):** toda la biomasa sólida (fibra+cuesco+EFB pretratado) a combustión → caldera 48 bar/470°C (Tabla 6 tesis) → turbina extrae vapor a 5 bar/159°C para proceso (esterilización continua + resto), remanente a condensación (0.22 bar/62°C) → biogás con POME.
- **Escenario 2 (contrapresión):** solo fibra+cuesco a combustión (EFB se retira, va a biogás) → turbina contrapresión (21 bar/230°C → 5 bar), vapor de escape = suministro térmico del proceso (esterilización convencional + clarificación dinámica + resto) → biogás con POME + EFB pretratado térmicamente (steam explosion, aumenta biodegradabilidad).
- **Esterilización continua** reemplaza convencional SOLO en Escenario 1 (315 kg vapor/tRFF, confirmado — no 542 como decía inicialmente la Tabla 10 por error de redacción). En Escenario 2 se revirtió a convencional por razones de costo/déficit de vapor (ver arriba).
- **Clarificación dinámica** reemplaza la convencional en AMBOS escenarios (Tabla 10: 0.6 kg vapor/tRFF, **1.5 kWh/tRFF** [corregido], 90 L agua/tRFF).
- **Pretratamiento mecánico de EFB** (tambor rotatorio, Tabla 11, Ocampo Batlle et al. 2020, Escenario 1) es DISTINTO del **pretratamiento térmico** (steam explosion, Tabla 14, Voogt et al. 2021, Escenario 2) — no confundir, tienen costos y funciones distintas.
- **BMP de EFB pretratado = 273.51 L CH4/kg SV**, validado 100% exacto con la ecuación de Thomsen et al. (2014) — usado en el balance interno de `Scenarios2` (no en nuestro modelo, que usa Tabla 15 para Escenario 2).
- **CEPCI 2026 ≈ 873.8** (estimado, año en curso) para ajustar todos los costos a USD 2026.
- **Eficiencia de caldera línea base** se calcula con método directo ASME (Ecuación de la tesis) + librería `iapws` (IAPWS-IF97) para entalpías — ya validado contra Planta A línea base (75.7%, dentro del rango tesis 54-76%).

## Plan de trabajo y cronograma de 6 meses

Ya existe un documento separado (`Plan_de_trabajo_Articulo_Capitulo5.md`) con el cronograma completo mes a mes — adjuntarlo también si se necesita retomar el plan general (aprendizaje Python/Pyomo + avance del artículo en paralelo).
